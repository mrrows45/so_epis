/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.problemapc;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author will_
 */
public class ProblemaPC {

    public static void main(String[] args) {       
        Cola colaCompartida = new Cola(5);

        Thread productorThread = new Thread(new Productor(colaCompartida));
        Thread consumidorThread = new Thread(new Consumidor(colaCompartida));

        productorThread.start();
        consumidorThread.start();
    }
}
class Cola {
    private Queue<Integer> cola;
    private int capacidad;

    public Cola(int capacidad) {
        this.cola = new LinkedList<>();
        this.capacidad = capacidad;
    }

    public synchronized void agregar(int elemento) {
        while (cola.size() == capacidad) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        cola.add(elemento);
        notifyAll();
    }

    public synchronized int eliminar() {
        while (cola.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        int elemento = cola.remove();
        notifyAll();
        return elemento;
    }
}

class Productor implements Runnable {
    private Cola cola;

    public Productor(Cola cola) {
        this.cola = cola;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 10; i++) {
            cola.agregar(i);
            System.out.println("Productor agrego: " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}

class Consumidor implements Runnable {
    private Cola cola;

    public Consumidor(Cola cola) {
        this.cola = cola;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 10; i++) {
            int elemento = cola.eliminar();
            System.out.println("Consumidor elimino: " + elemento);
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
